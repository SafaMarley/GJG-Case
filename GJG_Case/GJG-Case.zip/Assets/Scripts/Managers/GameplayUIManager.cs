using Managers.Base;

namespace Managers
{
    public class GameplayUIManager : MonoSingleton<GameplayUIManager>
    {
        public void Initialize()
        {
        }
    }
}
