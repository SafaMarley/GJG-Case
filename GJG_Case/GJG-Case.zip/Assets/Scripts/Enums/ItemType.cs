namespace Enums
{
    public enum ItemType
    {
        Red = 0,
        Pink,
        Yellow,
        Green,
        Blue,
        Purple
    }
}
